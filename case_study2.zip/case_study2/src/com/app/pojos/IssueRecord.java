package com.app.pojos;
import javax.persistence.*;


import java.util.Date;

@Entity
public class IssueRecord 
{
	private Integer id;
	private Date issueDate,returnDueDate,returnDate;
	private double fineAmount;
	private User user;
	private Copies copy;
	public IssueRecord() 
	{	}
	public IssueRecord(Date issueDate, Date returnDueDate, Date returnDate, double fineAmount) {
		super();
		this.issueDate = issueDate;
		this.returnDueDate = returnDueDate;
		this.returnDate = returnDate;
		this.fineAmount = fineAmount;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	@Temporal(TemporalType.DATE)
	public Date getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	@Temporal(TemporalType.DATE)
	public Date getReturnDueDate() {
		return returnDueDate;
	}
	public void setReturnDueDate(Date returnDueDate) {
		this.returnDueDate = returnDueDate;
	}
	@Temporal(TemporalType.DATE)
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}
	public double getFineAmount() {
		return fineAmount;
	}
	public void setFineAmount(double fineAmount) {
		this.fineAmount = fineAmount;
	}
	@ManyToOne
	@JoinColumn(name = "user_id")
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	@ManyToOne
	@JoinColumn(name = "copy_id")
	public Copies getCopy() {
		return copy;
	}
	public void setCopy(Copies copy) {
		this.copy = copy;
	}
	@Override
	public String toString() {
		return "IssueRecord [id=" + id + ", issueDate=" + issueDate + ", returnDueDate=" + returnDueDate
				+ ", returnDate=" + returnDate + ", fineAmount=" + fineAmount + "]";
	}
	
}
