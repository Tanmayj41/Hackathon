package com.app.pojos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
public class Copies implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer cid;
	private int rack;
	private String status;
	private Book book;
	private List<IssueRecord> issueRecords = new ArrayList<IssueRecord>();
	public Copies( ) {
		
	}
	
	public Copies( int rack, String status) {
		this.rack = rack;
		this.status = status;
	}
   
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public int getRack() {
		return rack;
	}

	public void setRack(int rack) {
		this.rack = rack;
	}
    
	@Column(length = 20)
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	@ManyToOne
	@JoinColumn(name = "b_id")	
	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	@OneToMany(mappedBy = "copy",cascade = CascadeType.ALL,orphanRemoval = true,fetch = FetchType.EAGER)
	public List<IssueRecord> getIssueRecords() {
		return issueRecords;
	}

	public void setIssueRecords(List<IssueRecord> issueRecords) {
		this.issueRecords = issueRecords;
	}

	public void addIssueRecord(IssueRecord issue)
	{
		this.issueRecords.add(issue);
		issue.setCopy(this);
	}
	public void removeIssueRecord(IssueRecord issue)
	{
		this.issueRecords.remove(issue);
		issue.setCopy(null);
	}
	@Override
	public String toString() {
		return "Copies [cid=" + cid + ", rack=" + rack + ", status=" + status + "]";
	}
}



