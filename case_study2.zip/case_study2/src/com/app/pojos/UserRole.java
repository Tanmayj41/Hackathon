package com.app.pojos;

public enum UserRole 
{
	MEMBER,LIBRARIAN,OWNER
}
