package com.app.pojos;

public enum PaymentType 
{
	NET_BANKING,DEBIT_CARD,CREDIT_CARD
}
