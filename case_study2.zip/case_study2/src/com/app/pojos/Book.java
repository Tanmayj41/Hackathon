package com.app.pojos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Book {	
	
	private Integer bid;
	private int isbn;
	private String name,author,subject;
    private double price;
    private List<Copies> copies=new ArrayList<>();
	public Book( ) {
		
		
		
	}
	
	public Book( int isbn, String name, String author, String subject, double price
			) {
		
		this.isbn = isbn;
		this.name = name;
		this.author = author;
		this.subject = subject;
		this.price = price;
		
	}

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getBid() {
		return bid;
	}

	public void setBid(Integer bid) {
		this.bid = bid;
	}

	public int getIsbn() {
		return isbn;
	}

	public void setIsbn(Integer isbn) {
		this.isbn = isbn;
	}
    
	@Column(length = 20)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
    
	@Column(length = 20)
	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}
   
	@Column(length = 20)
	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
     
	
	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@JsonIgnore
	@OneToMany(mappedBy = "book",cascade = CascadeType.ALL,orphanRemoval = true)
	public List<Copies> getCopies() {
		return copies;
	}

	public void setCopies(List<Copies> copies) {
		this.copies = copies;
	}

	public void addCopy(Copies copy)
	{
		this.copies.add(copy);
		copy.setBook(this);
	}
	public void removeCopy(Copies copy)
	{
		this.copies.remove(copy);
		copy.setBook(null);
	}

	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", name=" + name + ", author=" + author + ", subject=" + subject + ", price="
				+ price + "]";
	}
	
	
    

}
