package com.app.pojos;
import javax.persistence.*;
import java.util.Date;

@Entity
public class Payment 
{
	private Integer paymentId;
	private double amount;
	private PaymentType paymentType;
	private Date transactionTime,nextPaymentDueDate;
	private User user;
	public Payment() 
	{	}
	public Payment( double amount, PaymentType paymentType, Date transactionTime,
			Date nextPaymentDueDate) {
		super();
		this.amount = amount;
		this.paymentType = paymentType;
		this.transactionTime = transactionTime;
		this.nextPaymentDueDate = nextPaymentDueDate;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Enumerated(EnumType.STRING)
	public PaymentType getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(PaymentType paymentType) {
		this.paymentType = paymentType;
	}
	@Temporal(TemporalType.DATE)
	public Date getTransactionTime() {
		return transactionTime;
	}
	public void setTransactionTime(Date transactionTime) {
		this.transactionTime = transactionTime;
	}
	@Temporal(TemporalType.DATE)
	public Date getNextPaymentDueDate() {
		return nextPaymentDueDate;
	}
	public void setNextPaymentDueDate(Date nextPaymentDueDate) {
		this.nextPaymentDueDate = nextPaymentDueDate;
	}
	@ManyToOne
	@JoinColumn(name = "user_id")
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	@Override
	public String toString() {
		return "Payment [paymentId=" + paymentId + ", amount=" + amount + ", paymentType=" + paymentType
				+ ", transactionTime=" + transactionTime + ", nextPaymentDueDate=" + nextPaymentDueDate + "]";
	}
	
}
