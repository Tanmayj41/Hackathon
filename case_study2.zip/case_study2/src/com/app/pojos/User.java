package com.app.pojos;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
public class User 
{
	private Integer id;
	private String name,email,password,phone;
	private UserRole role;
	private List<Payment> payList = new ArrayList<>();
	private List<IssueRecord> issueRecords = new ArrayList<>();

	public User() 
	{	}

	public User(String name, String email, String password, String phone, UserRole role) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.phone = phone;
		this.role = role;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(length = 20)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(length = 20,unique = true)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(length = 20,nullable = false)
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(length = 20)
	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Enumerated(EnumType.STRING)
	public UserRole getRole() {
		return role;
	}

	public void setRole(UserRole role) {
		this.role = role;
	}
	@OneToMany(mappedBy = "user",orphanRemoval = true,cascade = CascadeType.ALL)
	public List<Payment> getPayList() {
		return payList;
	}

	public void setPayList(List<Payment> payList) {
		this.payList = payList;
	}

	public void addPayment(Payment payment)
	{
		this.payList.add(payment);
		payment.setUser(this);
	}
	public void removePayment(Payment payment)
	{
		this.payList.remove(payment);
		payment.setUser(null);
	}
	@OneToMany(mappedBy = "user",cascade = CascadeType.ALL,orphanRemoval = true)
	public List<IssueRecord> getIssueRecords() {
		return issueRecords;
	}

	public void setIssueRecords(List<IssueRecord> issueRecords) {
		this.issueRecords = issueRecords;
	}
	
	public void addIssueRecord(IssueRecord issue)
	{
		this.issueRecords.add(issue);
		issue.setUser(this);
	}
	public void removeIssueRecord(IssueRecord issue)
	{
		this.issueRecords.remove(issue);
		issue.setUser(null);
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", email=" + email + ", password=" + password + ", phone=" + phone
				+ ", role=" + role + "]";
	}
	
}
