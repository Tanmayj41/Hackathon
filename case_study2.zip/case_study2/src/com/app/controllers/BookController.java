package com.app.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.IBookDao;
import com.app.pojos.Book;
import com.app.pojos.Copies;

@RestController
@CrossOrigin
@RequestMapping("/books")
public class BookController {
	@Autowired
	private IBookDao dao;

	@GetMapping("/{bid}")
	public ResponseEntity<?> getCopiesByBookId(@PathVariable Integer bid) {
		Book book = dao.getCopiesByBookId(bid);
		System.out.println(book);
		List<Copies> list = book.getCopies();
		for (Copies copies : list) {
			System.out.println(copies);
		}
		return new ResponseEntity<List<Copies>>(list, HttpStatus.OK);
	}

	@PostMapping
	public ResponseEntity<?> addBook(@RequestBody Book b) {
		try {
			Book b1 = dao.addBook(b);
			
			System.out.println(b1);
			return new ResponseEntity<Book>(b1, HttpStatus.CREATED);
		} catch (RuntimeException e) {
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
