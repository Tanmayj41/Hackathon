package com.app.dao;


import com.app.pojos.Book;

public interface IBookDao 
{
	Book getCopiesByBookId(int id);

	Book addBook(Book b);
}
