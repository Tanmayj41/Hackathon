package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Book;
import com.app.pojos.Copies;

@Repository
@Transactional
public class BookDao implements IBookDao 
{
	@Autowired
	private SessionFactory sf;
	@Override
	public Book getCopiesByBookId(int id) 
	{	
		//"select v from Vendor v left outer join fetch v.accounts where v.id=:v_id";
		String jpql = "select b from Book b left outer join fetch b.copies where b.id=:bid";
		return sf.getCurrentSession().createQuery(jpql, Book.class).setParameter("bid", id).getSingleResult();
	}
	@Override
	public Book addBook(Book b)
	{
		sf.getCurrentSession().save(b);
		Copies c1 = new Copies(1, "AVAILABLE");
		b.addCopy(c1);
		return b;
	}

}
