import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-check-book-availability',
  templateUrl: './check-book-availability.component.html',
  styleUrls: ['./check-book-availability.component.css']
})
export class CheckBookAvailabilityComponent implements OnInit {

  no:any
  copies:any
  constructor(private service:DataService,
            private route: ActivatedRoute,
              private router: Router) { }
  ngOnInit() 
  {
    this.route.paramMap.subscribe((result)=>{
      this.no = result.get("no");
     })
  }
  find()
  {
    var obs = this.service.selectCopies(this.no);
    obs.subscribe((result)=>{
      this.copies = result;
    })
  }
}
