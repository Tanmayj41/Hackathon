import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckBookAvailabilityComponent } from './check-book-availability.component';

describe('CheckBookAvailabilityComponent', () => {
  let component: CheckBookAvailabilityComponent;
  let fixture: ComponentFixture<CheckBookAvailabilityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckBookAvailabilityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckBookAvailabilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
