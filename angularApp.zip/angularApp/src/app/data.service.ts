import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http:HttpClient) { }

  selectCopies(id)
  {
    return this.http.get("http://localhost:8080/case_study2/books/"+id);
  }
  addBook(book)
  {
    return this.http.post("http://localhost:8080/case_study2/books/",book);
  }
}
