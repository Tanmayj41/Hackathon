import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { EditComponent } from './edit/edit.component';
import { ChangePassComponent } from './change-pass/change-pass.component';
import { CheckBookAvailabilityComponent } from './check-book-availability/check-book-availability.component';
import { RouterModule } from '@angular/router'
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, NgForm, NgModel} from '@angular/forms';
import { AddNewBookComponent } from './add-new-book/add-new-book.component';
 @NgModule({
  declarations: [
    AppComponent,
    EditComponent,
    ChangePassComponent,
    CheckBookAvailabilityComponent,
    AddNewBookComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path:'checkBookAvailablity',component:CheckBookAvailabilityComponent},
      {path:'contact',component:EditComponent},
      {path:'addNewBook',component:AddNewBookComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
