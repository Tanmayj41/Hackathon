import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-add-new-book',
  templateUrl: './add-new-book.component.html',
  styleUrls: ['./add-new-book.component.css']
})
export class AddNewBookComponent implements OnInit {

  book={"Name": "","Author":"","Subject":"","Price":"","ISBN":""}

  constructor(private service:DataService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() 
  {
    this.route.paramMap.subscribe((result)=>{
      console.log(result);
      this.book = result[0];
    })
  }
  add()
  {
    let observable = this.service.addBook(this.book);
    observable.subscribe((result)=>{
      console.log(result);
    })
    this.router.navigate(['/checkBookAvailablity']);
  }
}
